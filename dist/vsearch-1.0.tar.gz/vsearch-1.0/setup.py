from setuptools import setup

setup(
    name='vsearch',
    version='1.0',
    description='изучаем Python, инструменты поиска',
    author='Ilya Piminov',
    author_email='ilyapiminov@gmail.com',
    py_modules=['vsearch'],
)
    
